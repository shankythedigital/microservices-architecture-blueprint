

package com.example.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Base64;
import java.util.Properties;
import java.util.stream.Stream;

/**
 * Locates and normalizes an encryption key to a Base64-encoded 32-byte value
 * suitable for AES-256 (what JpaAttributeEncryptor expects).
 *
 * Search order (first match wins):
 *  1) ENV: AUTH_ENC_KEY
 *  2) ENV: ENCRYPTION_KEY
 *  3) System property: auth.enc.key
 *  4) env/.env.auth (key AUTH_ENC_KEY)
 *  5) env/.env (keys AUTH_ENC_KEY or ENCRYPTION_KEY)
 *  6) single-line file: encryption.key under common-service resources
 *  7) properties file: enc.properties (auth.enc.key or encryption.key)
 *
 * If an ASCII/raw key is found it is converted to bytes, then padded/truncated to 32 bytes.
 * If a Base64 string is found, it's decoded; result padded/truncated to 32 bytes.
 *
 * Returns a Base64 string of exactly 32 bytes.
 */
public final class EncryptionKeyProvider {

    // Default resources path — adjust if your project layout differs.
    private static final Path COMMON_RESOURCES = Paths.get(
            "/Users/neilnaik/Documents/Shashank/Asset-LifeCycle-Management/Complete-Asset-Management/Github/microservices-architecture-blueprint/common-service/src/main/resources"
    );
    private static final Path ENV_DIR = COMMON_RESOURCES.resolve("env");
    private static final Path ENV_AUTH_FILE = ENV_DIR.resolve(".env.auth");
    private static final Path ENV_FILE = ENV_DIR.resolve(".env");
    private static final Path KEY_FILE = COMMON_RESOURCES.resolve("encryption.key");
    private static final Path PROPS_FILE = COMMON_RESOURCES.resolve("enc.properties");

    private static final int KEY_LEN = 32; // bytes for AES-256

    private EncryptionKeyProvider() { /* static helper */ }

    /**
     * Locate an encryption key and return it as a Base64-encoded 32-byte value.
     * Throws IllegalStateException if no valid key is found.
     */
    public static String getNormalizedBase64Key() {
        String raw = null;

        // 1,2) environment variables
        raw = firstNonBlank(System.getenv("AUTH_ENC_KEY"), System.getenv("ENCRYPTION_KEY"));

        // 3) system property
        if (isBlank(raw)) {
            raw = System.getProperty("auth.enc.key");
        }

        // 4) .env.auth
        if (isBlank(raw) && Files.isReadable(ENV_AUTH_FILE)) {
            raw = readKeyFromEnvFile(ENV_AUTH_FILE, "AUTH_ENC_KEY");
        }

        // 5) .env
        if (isBlank(raw) && Files.isReadable(ENV_FILE)) {
            raw = readKeyFromEnvFile(ENV_FILE, "AUTH_ENC_KEY");
            if (isBlank(raw)) raw = readKeyFromEnvFile(ENV_FILE, "ENCRYPTION_KEY");
        }

        // 6) single-line key file
        if (isBlank(raw) && Files.isReadable(KEY_FILE)) {
            raw = readSingleLineFile(KEY_FILE);
        }

        // 7) properties file
        if (isBlank(raw) && Files.isReadable(PROPS_FILE)) {
            raw = readFromProperties(PROPS_FILE, "auth.enc.key", "encryption.key");
        }

        if (isBlank(raw)) {
            throw new IllegalStateException("No encryption key found. Provide AUTH_ENC_KEY or ENCRYPTION_KEY env var, system property auth.enc.key, "
                    + ENV_AUTH_FILE + " (.env.auth), " + ENV_FILE + " (.env), " + KEY_FILE + " (encryption.key), or " + PROPS_FILE + " (enc.properties).");
        }

        // Normalize: if value appears Base64, decode it, else treat as UTF-8 bytes.
        byte[] keyBytes = tryBase64Decode(raw);
        if (keyBytes == null) {
            keyBytes = raw.getBytes(StandardCharsets.UTF_8);
        }

        // Pad or truncate to KEY_LEN
        if (keyBytes.length != KEY_LEN) {
            byte[] normalized = new byte[KEY_LEN];
            int copy = Math.min(keyBytes.length, KEY_LEN);
            System.arraycopy(keyBytes, 0, normalized, 0, copy);
            keyBytes = normalized;
        }

        // Return Base64-encoded 32-byte string
        return Base64.getEncoder().encodeToString(keyBytes);
    }

    // ---------------- helpers ----------------

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static String firstNonBlank(String... vals) {
        if (vals == null) return null;
        for (String v : vals) if (!isBlank(v)) return v;
        return null;
    }

    private static byte[] tryBase64Decode(String s) {
        try {
            byte[] dec = Base64.getDecoder().decode(s);
            // if decoding yields < 1 byte, consider it invalid
            if (dec == null || dec.length == 0) return null;
            return dec;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static String readKeyFromEnvFile(Path p, String keyName) {
        try (Stream<String> lines = Files.lines(p, StandardCharsets.UTF_8)) {
            return lines
                    .map(String::trim)
                    .filter(line -> !line.isEmpty() && !line.startsWith("#"))
                    .map(line -> {
                        int idx = line.indexOf('=');
                        if (idx <= 0) return null;
                        String k = line.substring(0, idx).trim();
                        String v = line.substring(idx + 1).trim();
                        return k.equals(keyName) ? v : null;
                    })
                    .filter(v -> v != null && !v.isEmpty())
                    .findFirst()
                    .orElse(null);
        } catch (IOException e) {
            return null;
        }
    }

    private static String readSingleLineFile(Path p) {
        try (BufferedReader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            String line = r.readLine();
            return (line == null) ? null : line.trim();
        } catch (IOException e) {
            return null;
        }
    }

    private static String readFromProperties(Path p, String... keys) {
        Properties props = new Properties();
        try (BufferedReader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            props.load(r);
            for (String k : keys) {
                String v = props.getProperty(k);
                if (!isBlank(v)) return v.trim();
            }
        } catch (IOException ignored) {
        }
        return null;
    }
}

