package com.example.common.util;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * AES-GCM encrypt/decrypt helper. Uses 12-byte IV and 128-bit tag.
 * Not a production KMS. Use a proper key management in prod.
 */
public class AesGcmEncryptor {

    private static final String ALGO = "AES/GCM/NoPadding";
    private static final int IV_SIZE = 12;
    private static final int TAG_BITS = 128;

    private final byte[] key;

    public AesGcmEncryptor(byte[] key) {
        if (key == null || (key.length != 16 && key.length != 32)) {
            throw new IllegalArgumentException("Invalid AES key length (16 or 32 bytes)");
        }
        this.key = key;
    }

    public String encrypt(String plaintext) {
        try {
            byte[] iv = new byte[IV_SIZE];
            SecureRandom random = new SecureRandom();
            random.nextBytes(iv);
            Cipher cipher = Cipher.getInstance(ALGO);
            SecretKeySpec ks = new SecretKeySpec(key, "AES");
            GCMParameterSpec spec = new GCMParameterSpec(TAG_BITS, iv);
            cipher.init(Cipher.ENCRYPT_MODE, ks, spec);
            byte[] ct = cipher.doFinal(plaintext.getBytes());
            byte[] combined = new byte[iv.length + ct.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(ct, 0, combined, iv.length, ct.length);
            return Base64.getEncoder().encodeToString(combined);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String decrypt(String cipherTextB64) {
        try {
            byte[] combined = Base64.getDecoder().decode(cipherTextB64);
            byte[] iv = new byte[IV_SIZE];
            System.arraycopy(combined, 0, iv, 0, iv.length);
            byte[] ct = new byte[combined.length - iv.length];
            System.arraycopy(combined, iv.length, ct, 0, ct.length);
            Cipher cipher = Cipher.getInstance(ALGO);
            SecretKeySpec ks = new SecretKeySpec(key, "AES");
            GCMParameterSpec spec = new GCMParameterSpec(TAG_BITS, iv);
            cipher.init(Cipher.DECRYPT_MODE, ks, spec);
            byte[] pt = cipher.doFinal(ct);
            return new String(pt);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
