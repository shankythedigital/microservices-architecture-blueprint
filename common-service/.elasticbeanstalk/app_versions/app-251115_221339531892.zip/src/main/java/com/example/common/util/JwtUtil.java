



package com.example.common.util;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.Instant;
import java.util.*;

/**
 * ✅ Shared JWT utility for all microservices.
 * Supports both:
 *  - RSA (public/private PEM keypair) signing (RS256)
 *  - HMAC (HS256) secret key signing
 *
 * Loads config from environment variables or Spring Boot properties.
 * Automatically determines signing mode at startup.
 */
@Component
public class JwtUtil {

    // ------------------------------------------------------------------------
    // 🔧 Configurable properties (Spring Boot / environment)
    // ------------------------------------------------------------------------
    @Value("${JWT_PRIVATE_KEY_PATH:#{null}}")
    private Resource privateKeyResource;

    @Value("${JWT_PUBLIC_KEY_PATH:#{null}}")
    private Resource publicKeyResource;

    @Value("${JWT_SECRET:#{null}}")
    private String hmacSecret;

    @Value("${JWT_ACCESS_TOKEN_VALIDITY_SECONDS:900}") // 15 minutes default
    private long accessTokenValiditySeconds;

    @Value("${JWT_REFRESH_TOKEN_VALIDITY_SECONDS:1209600}") // 14 days default
    private long refreshTokenValiditySeconds;

    // ------------------------------------------------------------------------
    // 🔑 Internal key material
    // ------------------------------------------------------------------------
    private PrivateKey privateKey;
    private PublicKey publicKey;
    private Key hmacKey;
    private boolean useRsa = false;

    // ------------------------------------------------------------------------
    // 🚀 Initialization
    // ------------------------------------------------------------------------
    @PostConstruct
    private void init() {
        try {
            // Attempt to load RSA keys first
            if (publicKeyResource != null && publicKeyResource.exists()) {
                this.publicKey = loadPublicKey(publicKeyResource);
                System.out.println("🔒 [JwtUtil] Loaded RSA public key");
                useRsa = true;
            }

            if (privateKeyResource != null && privateKeyResource.exists()) {
                this.privateKey = loadPrivateKey(privateKeyResource);
                System.out.println("🔑 [JwtUtil] Loaded RSA private key");
                useRsa = true;
            }

            // Fallback to HMAC mode if RSA keys not found
            if (!useRsa) {
                if (hmacSecret == null || hmacSecret.isBlank() || hmacSecret.length() < 32) {
                    throw new IllegalArgumentException(
                            "❌ JWT_SECRET must be at least 32 characters long when RSA keys are not provided");
                }
                this.hmacKey = Keys.hmacShaKeyFor(hmacSecret.getBytes(StandardCharsets.UTF_8));
                System.out.println("⚡ [JwtUtil] Using HMAC (HS256) mode for JWT");
            }

            System.out.printf("✅ [JwtUtil] Initialized — Algorithm: %s%n", useRsa ? "RS256" : "HS256");

        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize JwtUtil: " + e.getMessage(), e);
        }
    }

    // ------------------------------------------------------------------------
    // 🧩 Key Loaders
    // ------------------------------------------------------------------------
    private PrivateKey loadPrivateKey(Resource resource) throws Exception {
        try (InputStream is = resource.getInputStream()) {
            String keyPem = new String(is.readAllBytes(), StandardCharsets.UTF_8)
                    .replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "")
                    .replaceAll("\\s+", "");
            byte[] decoded = Base64.getDecoder().decode(keyPem);
            return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(decoded));
        }
    }

    private PublicKey loadPublicKey(Resource resource) throws Exception {
        try (InputStream is = resource.getInputStream()) {
            String keyPem = new String(is.readAllBytes(), StandardCharsets.UTF_8)
                    .replace("-----BEGIN PUBLIC KEY-----", "")
                    .replace("-----END PUBLIC KEY-----", "")
                    .replaceAll("\\s+", "");
            byte[] decoded = Base64.getDecoder().decode(keyPem);
            return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(decoded));
        }
    }

    // ------------------------------------------------------------------------
    // 🔐 Token Generation
    // ------------------------------------------------------------------------
    public String generateAccessToken(Long userId, String username, Long sessionId, List<String> roles) {
        Instant now = Instant.now();
        Date expiry = Date.from(now.plusSeconds(accessTokenValiditySeconds));
    
        Map<String, Object> claims = new HashMap<>();
        claims.put("uid", userId);
        claims.put("sid", sessionId);
        claims.put("roles", roles);
        claims.put("username", username); // ✅ add username
    
        JwtBuilder builder = Jwts.builder()
                .setSubject(String.valueOf(userId))
                .addClaims(claims)
                .setIssuedAt(Date.from(now))
                .setExpiration(expiry);
    
        signToken(builder);
        return builder.compact();
    }
    
    public String generateRefreshToken(Long userId, String username, Long sessionId) {
        Instant now = Instant.now();
        Date expiry = Date.from(now.plusSeconds(refreshTokenValiditySeconds));
    
        Map<String, Object> claims = new HashMap<>();
        claims.put("uid", userId);
        claims.put("sid", sessionId);
        claims.put("username", username); // ✅ add username
    
        JwtBuilder builder = Jwts.builder()
                .setSubject(String.valueOf(userId))
                .addClaims(claims)
                .setIssuedAt(Date.from(now))
                .setExpiration(expiry);
    
        signToken(builder);
        return builder.compact();
    }
    public String generateServiceToken() {
        // 🧠 Used for internal service-to-service authentication
        // Assigns a fixed "service" username and ROLE_SERVICE role
        Long systemUserId = 0L;
        Long systemSessionId = 0L;
        String systemUsername = "service";
        List<String> systemRoles = List.of("ROLE_SERVICE");
    
        return generateAccessToken(systemUserId, systemUsername, systemSessionId, systemRoles);
    }
    

    public String getUsername(String token) {
        Object username = parseToken(token).getBody().get("username");
        return username != null ? username.toString() : null;
    }
    

    private void signToken(JwtBuilder builder) {
        if (useRsa && privateKey != null) {
            builder.signWith(privateKey, SignatureAlgorithm.RS256);
        } else {
            builder.signWith(hmacKey, SignatureAlgorithm.HS256);
        }
    }

    // ------------------------------------------------------------------------
    // 🔍 Token Parsing and Validation
    // ------------------------------------------------------------------------
    public Jws<Claims> parseToken(String token) {
        JwtParserBuilder parser = Jwts.parserBuilder();
        if (useRsa) {
            parser.setSigningKey(publicKey);
        } else {
            parser.setSigningKey(hmacKey);
        }
        return parser.build().parseClaimsJws(token);
    }

    public boolean validateToken(String token) {
        try {
            parseToken(token);
            return true;
        } catch (JwtException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------------
    // 🧾 Accessor Helpers
    // ------------------------------------------------------------------------
    public String getUserId(String token) {
        return parseToken(token).getBody().getSubject();
    }

    public Long getSessionId(String token) {
        Object sid = parseToken(token).getBody().get("sid");
        return sid != null ? Long.parseLong(sid.toString()) : null;
    }

    @SuppressWarnings("unchecked")
    public List<String> getRoles(String token) {
        Object roles = parseToken(token).getBody().get("roles");
        return roles instanceof List ? (List<String>) roles : Collections.emptyList();
    }

    public long getAccessTokenValiditySeconds() {
        return accessTokenValiditySeconds;
    }

    public long getRefreshTokenValiditySeconds() {
        return refreshTokenValiditySeconds;
    }

    public boolean isUsingRsa() {
        return useRsa;
    }
}


