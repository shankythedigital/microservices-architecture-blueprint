package com.example.common.converter;

import com.example.common.util.AesGcmEncryptor;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.nio.charset.StandardCharsets;

import java.util.Base64;

/**
 * JPA attribute converter using AesGcmEncryptor.
 * Reads key from env ENCRYPTION_KEY (expects 16 or 32 bytes).
 */
@Converter
public class JpaAttributeEncryptor implements AttributeConverter<String, String> {

    
    private static AesGcmEncryptor encryptor;

    // Initialize the encryptor once at application startup
    public static void init(String base64Key) {
        byte[] key = Base64.getDecoder().decode(base64Key);
        encryptor = new AesGcmEncryptor(key);
    }

    public JpaAttributeEncryptor() {
        String k = System.getenv().getOrDefault("ENCRYPTION_KEY", "0123456789abcdef"); // default 16 bytes
        byte[] key = k.getBytes(StandardCharsets.UTF_8);
        this.encryptor = new AesGcmEncryptor(key);
    }

    @Override
    public String convertToDatabaseColumn(String attribute) {
        if (attribute == null) return null;
        return encryptor.encrypt(attribute);
    }

    @Override
    public String convertToEntityAttribute(String dbData) {
        if (dbData == null) return null;
        return encryptor.decrypt(dbData);
    }
}
