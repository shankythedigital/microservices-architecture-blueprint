
package com.example.common.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.security.KeyFactory;
import java.util.Base64;
import java.util.List;
import java.util.Collections;
import lombok.extern.slf4j.Slf4j;



/**
 * ✅ JwtVerifier
 * Lightweight read-only verifier for downstream microservices.
 * Loads ONLY the public key (RSA) or HMAC secret (for local dev fallback).
 */
@Slf4j
@Component
public class JwtVerifier {

    

    // 👇 add this line — this creates the logger explicitly
    private static final Logger log = LoggerFactory.getLogger(JwtVerifier.class);

    @Value("${JWT_PUBLIC_KEY_PATH:#{null}}")
    private Resource publicKeyResource;

    @Value("${JWT_SECRET:#{null}}")
    private String hmacSecret;

    private PublicKey publicKey;
    private Key hmacKey;
    private boolean useRsa = false;

    @PostConstruct
    private void init() {
        try {
            if (publicKeyResource != null && publicKeyResource.exists()) {
                this.publicKey = loadPublicKey(publicKeyResource);
                this.useRsa = true;
                System.out.println("🔒 [JwtVerifier] Loaded RSA public key for JWT validation");
            } else if (hmacSecret != null && hmacSecret.length() >= 32) {
                this.hmacKey = Keys.hmacShaKeyFor(hmacSecret.getBytes(StandardCharsets.UTF_8));
                this.useRsa = false;
                System.out.println("⚡ [JwtVerifier] Using HMAC (HS256) for local JWT validation");
            } else {
                throw new IllegalArgumentException("❌ Must provide either JWT_PUBLIC_KEY_PATH or a valid JWT_SECRET (≥32 chars)");
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize JwtVerifier: " + e.getMessage(), e);
        }
    }

    // ------------------------------------------------------------
    // ✅ Public verification methods
    // ------------------------------------------------------------
    public Jws<Claims> parseToken(String token) {
        JwtParserBuilder parser = Jwts.parserBuilder();
        if (useRsa) {
            parser.setSigningKey(publicKey);
        } else {
            parser.setSigningKey(hmacKey);
        }
        return parser.build().parseClaimsJws(token);
    }

    public Claims validateToken(String token) {
        if (token == null || token.isBlank()) {
            throw new JwtException("Missing JWT token");
        }

        String actualToken = token.startsWith("Bearer ") ? token.substring(7) : token;

        try {
            return Jwts.parserBuilder()
                    .setSigningKey(publicKey)
                    .build()
                    .parseClaimsJws(actualToken)
                    .getBody();
        } catch (JwtException ex) {
            log.error("❌ Invalid JWT: {}", ex.getMessage());
            throw ex;
        }
    }


    public String getUserId(String token) {
        return parseToken(token).getBody().getSubject();
    }

    @SuppressWarnings("unchecked")
    public List<String> getRoles(String token) {
        Object roles = parseToken(token).getBody().get("roles");
        return roles instanceof List ? (List<String>) roles : Collections.emptyList();
    }

    // ------------------------------------------------------------
    // 🔑 Load RSA public key
    // ------------------------------------------------------------
    private PublicKey loadPublicKey(Resource resource) throws Exception {
        try (InputStream is = resource.getInputStream()) {
            String keyPem = new String(is.readAllBytes(), StandardCharsets.UTF_8)
                    .replace("-----BEGIN PUBLIC KEY-----", "")
                    .replace("-----END PUBLIC KEY-----", "")
                    .replaceAll("\\s+", "");
            byte[] decoded = Base64.getDecoder().decode(keyPem);
            return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(decoded));
        }
    }
}



