package com.example.common;

public class MainClass {
    public static void main(String[] args) {
        System.out.println("✅ common-service module ready.");
    }
}
