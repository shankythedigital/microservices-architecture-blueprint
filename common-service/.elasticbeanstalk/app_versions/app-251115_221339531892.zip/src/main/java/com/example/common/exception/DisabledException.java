package com.example.common.exception;
public class DisabledException extends RuntimeException {
    public DisabledException(String msg){ super(msg); }
}
