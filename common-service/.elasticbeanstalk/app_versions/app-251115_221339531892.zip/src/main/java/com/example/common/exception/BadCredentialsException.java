package com.example.common.exception;
public class BadCredentialsException extends RuntimeException {
    public BadCredentialsException(String msg){ super(msg); }
}
